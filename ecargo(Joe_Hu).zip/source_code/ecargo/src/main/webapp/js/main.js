/**
 * main.js
 */

var app = angular.module('ecargoApp',['ngAnimate','ui.bootstrap']); //init angular app

