-- @Description query product with latest review procedure;
-- @Param var_brand_id; brand's id if var_brand_id<0 query any product else query product by brand id 
-- @Param  var_row_num; how many row would return
CREATE  PROCEDURE sq_query_product (IN var_brand_name VARCHAR(20),
                              IN var_row_num INT)
BEGIN
	IF var_brand_name="" then
		select product_id, product_name, product_desc, product_create_date, brand_id, brand_name, comment, rating, user_name, review_create_date 
		from v_product ORDER BY product_create_date desc limit 0,var_row_num;
	ELSE
		select  product_id, product_name, product_desc, product_create_date, brand_id, brand_name, comment, rating, user_name, review_create_date
		from v_product WHERE brand_name like var_brand_name ORDER BY product_create_date desc limit 0,var_row_num;
  END IF;
END;

-- @Description create product query view which could query the lastes review of product
CREATE OR REPLACE view v_product AS
SELECT p.id product_id, p.name product_name, p.desc product_desc,p.create_date product_create_date, b.id brand_id,
b.name brand_name, r.comment, r.rating, u.name user_name, r.create_date review_create_date
 FROM t_product p 
 LEFT JOIN  t_review r on r.product_id=p.id and is_new=1
 INNER JOIN t_brand b on b.id=p.brand_id
 LEFT JOIN t_user u on u.id=r.user_id;

-- @Create index for query optimization
CREATE INDEX t_brand_index ON t_brand (name);
CREATE INDEX t_review_usrid_index ON t_review (user_id);
CREATE INDEX t_review_prdid_index ON t_review (product_id);
CREATE INDEX t_user_email_index ON t_user (email);