/*
Navicat MySQL Data Transfer

Source Server         : localhost
Source Server Version : 50536
Source Host           : localhost:3306
Source Database       : ecargo_test

Target Server Type    : MYSQL
Target Server Version : 50536
File Encoding         : 65001

Date: 2015-09-09 17:30:12
*/

SET FOREIGN_KEY_CHECKS=0;
-- ----------------------------
-- Table structure for `t_brand`
-- ----------------------------
DROP TABLE IF EXISTS `t_brand`;
CREATE TABLE `t_brand` (
  `id` int(11) NOT NULL AUTO_INCREMENT COMMENT 'brand unique key',
  `name` varchar(100) NOT NULL COMMENT 'brand name',
  `desc` varchar(1000) DEFAULT NULL COMMENT 'brand description',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of t_brand
-- ----------------------------
INSERT INTO t_brand VALUES ('1', 'Apple', 'Apple is an American multinational technology company headquartered in Cupertino, California, that designs, develops, and sells consumer electronics, computer software, and online services');
INSERT INTO t_brand VALUES ('2', 'Louis Vuitton', 'Louis Vuitton was founded by Vuitton in 1854 on Rue Neuve des Capucines in Paris, France.');
INSERT INTO t_brand VALUES ('3', 'XiaoMi', 'XiaoMi is a privately owned Chinese electronics company headquartered in Beijing, China, that is the world\'s 4th[4] largest smartphone maker. Xiaomi designs, develops, and sells smartphones, mobile apps, and related consumer electronics.');

-- ----------------------------
-- Table structure for `t_product`
-- ----------------------------
DROP TABLE IF EXISTS `t_product`;
CREATE TABLE `t_product` (
  `id` int(11) NOT NULL COMMENT 'unique key ',
  `name` varchar(100) NOT NULL COMMENT 'product name',
  `desc` varchar(1000) DEFAULT NULL COMMENT 'product description',
  `price` double(10,2) NOT NULL COMMENT 'product price',
  `color` varchar(8) DEFAULT NULL COMMENT 'product color',
  `create_date` datetime NOT NULL COMMENT 'product create date',
  `status` varchar(4) NOT NULL COMMENT 'availability status (i - in stock; o - out of stock, a - archived)',
  `brand_id` int(11) NOT NULL COMMENT 'FK from brand',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of t_product
-- ----------------------------
INSERT INTO t_product VALUES ('1', 'IPHONE', 'IPHONE the best phone in the world', '5800.00', 'white', '2015-09-07 14:46:32', 'i', '1');
INSERT INTO t_product VALUES ('2', 'IPAD', 'IPAD the best pad in the world', '2900.00', 'blue', '2015-09-07 14:47:49', 'i', '1');
INSERT INTO t_product VALUES ('3', 'IWATCH', 'IWATCH the best watch in the world', '3099.00', 'black', '2015-09-07 14:49:03', 'i', '1');
INSERT INTO t_product VALUES ('4', 'MAC PRO', 'MAC PRO the best laptop in the world', '9999.00', 'black', '2015-09-07 14:52:04', 'i', '1');
INSERT INTO t_product VALUES ('5', 'IMAC', 'IMAC the best destop in the world', '1299.00', 'black', '2015-09-07 14:52:53', 'i', '1');
INSERT INTO t_product VALUES ('6', 'IPOD', 'IPOD the best music pod in the world', '1999.00', 'black', '2015-09-09 14:05:15', 'i', '1');
INSERT INTO t_product VALUES ('7', 'HANDBAG', 'LV HANDBAG IS YOUR CHOICE', '15888.00', 'black', '2015-09-09 15:06:47', 'i', '2');
INSERT INTO t_product VALUES ('8', 'SHOES', 'LV SHOES IS YOUR SHOES', '7999.00', 'black', '2015-09-09 16:07:20', 'i', '2');
INSERT INTO t_product VALUES ('9', 'MI 1', 'XIAOMI 1 the first smart phone of xiaomi', '1599.00', 'black', '2015-09-09 17:01:21', 'i', '3');
INSERT INTO t_product VALUES ('10', 'MI 2', 'XIAOMI 2 the second smart phone of xiaomi', '1699.00', 'black', '2015-09-09 17:02:21', 'i', '3');
INSERT INTO t_product VALUES ('11', 'MI 3', 'XIAOMI 3 the third smart phone of xiaomi', '1799.00', 'black', '2015-09-09 17:03:21', 'i', '3');
INSERT INTO t_product VALUES ('12', 'MI 4', 'XIAOMI 4 the forth smart phone of xiaomi', '1899.00', 'black', '2015-09-09 17:04:21', 'i', '3');
INSERT INTO t_product VALUES ('13', 'MI 5', 'XIAOMI 5 the fivth smart phone of xiaomi', '1999.00', 'black', '2015-09-09 17:05:21', 'i', '3');
INSERT INTO t_product VALUES ('14', 'MI ROUTER', 'XIAOMI ROUTER', '599.00', 'black', '2015-09-09 17:06:21', 'i', '3');
INSERT INTO t_product VALUES ('15', 'XIAOMI TV', 'XIAOMI TV is easy for you', '3599.00', 'black', '2015-09-09 17:07:21', 'i', '3');
INSERT INTO t_product VALUES ('16', 'XIAOMI PAD', 'XIAOMI PAD is cheaper than ipad', '1488.00', 'black', '2015-09-09 17:08:21', 'i', '3');

-- ----------------------------
-- Table structure for `t_review`
-- ----------------------------
DROP TABLE IF EXISTS `t_review`;
CREATE TABLE `t_review` (
  `id` int(11) NOT NULL AUTO_INCREMENT COMMENT 'unique key',
  `rating` smallint(6) NOT NULL COMMENT 'review rate (0-10)',
  `comment` varchar(1000) DEFAULT NULL COMMENT 'review comments',
  `product_id` int(11) NOT NULL COMMENT 'FK from product',
  `user_id` int(11) NOT NULL COMMENT 'FK from user',
  `create_date` datetime NOT NULL COMMENT 'create date of review',
  `is_new` tinyint(4) NOT NULL DEFAULT '0' COMMENT 'mark the review is the newest. 0-not newest, 1-newest',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=47 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of t_review
-- ----------------------------
INSERT INTO t_review VALUES ('41', '10', 'ipod音乐播放器还不错, 性价比高, 并且是替代walkman的革命性产品, 给一个\"赞\"!', '6', '1', '2015-09-09 17:21:04', '1');
INSERT INTO t_review VALUES ('42', '9', '小米的PAD设计和质量一般般, 和ipad相比还是有一点点差距的, 不过小米PAD在安卓市场还是可以秒杀一切对手的, 给一个赞!', '16', '1', '2015-09-09 17:23:49', '1');
INSERT INTO t_review VALUES ('43', '10', 'This is my first time using android phone, but i have to say xiaomi 5 is great phone.', '13', '2', '2015-09-09 17:24:35', '1');
INSERT INTO t_review VALUES ('44', '5', 'husdfsdf', '12', '1', '2015-09-09 17:24:52', '0');
INSERT INTO t_review VALUES ('45', '8', 'not bad', '12', '2', '2015-09-09 17:25:14', '1');
INSERT INTO t_review VALUES ('46', '7', 'girl\'s dream bag, but only once. when they weak up, it is not that good. however, everything consuming product depends on an glance feeling', '7', '1', '2015-09-09 17:27:15', '1');

-- ----------------------------
-- Table structure for `t_user`
-- ----------------------------
DROP TABLE IF EXISTS `t_user`;
CREATE TABLE `t_user` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(100) NOT NULL,
  `type` varchar(4) NOT NULL COMMENT 'user type(c - customer, m - merchant)',
  `email` varchar(100) NOT NULL,
  `birth_date` date NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of t_user
-- ----------------------------
INSERT INTO t_user VALUES ('1', 'hushenglang', 'c', 'hushenglang@gmail.com', '1986-07-01');
INSERT INTO t_user VALUES ('2', 'jack ma', 'c', 'jackma@gmail.com', '2015-09-07');
INSERT INTO t_user VALUES ('3', 'merchant', 'm', 'merchant@gmail.com', '2015-09-09');
