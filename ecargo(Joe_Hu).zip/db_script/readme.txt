#readme.txt#

This file will tell you how to init database of ecargo, please follow the steps:

1.create new database named "ecargo_test" and set character-set="utf-8" in mysql server;
2.execute table_init.sql script file firstly;
3.execute other_init.sql script file lastly.

ps: make sure mysql server support InnoDB.
 
